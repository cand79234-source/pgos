# Personal Growth OS · GitHub Pages 部署

> 5 分钟获得固定网址，手机点击 ntfy 通知直达网页。

## 你将获得

- 固定网址：`https://你的用户名.github.io/pgos`
- 手机 ntfy 通知点击直达该网址
- 完全免费，无需服务器

---

## 第 1 步 · 创建 GitHub 仓库（2 分钟）

1. 打开 https://github.com → 登录（或注册，用邮箱即可）
2. 右上角 **+** → **New repository**
3. 填写：
   - **Repository name**：`pgos`（必须小写）
   - 选 **Public**（Public 才能免费使用 Pages）
   - 勾选 **Add a README file**
   - 点 **Create repository**

---

## 第 2 步 · 上传文件（2 分钟）

1. 进入你的 `pgos` 仓库页面
2. 点 **Add file** → **Upload files**
3. 把下面这 **4 个文件** 拖进上传区：
   - `index.html`
   - `tasks.html`
   - `news.html`
   - `reviews.html`
4. 点 **Commit changes**

> 注意：不要上传成文件夹，4 个文件必须直接在仓库根目录。

---

## 第 3 步 · 开启 GitHub Pages（1 分钟）

1. 仓库页面 → 顶部菜单 **Settings**（最后一个标签）
2. 左侧边栏 → **Pages**（在 Code and automation 下面）
3. **Source** 部分：
   - Branch: 选 `main`
   - Folder: 选 `/(root)`
   - 点 **Save**
4. 等 1~2 分钟，页面会显示绿色提示：
   > Your site is live at `https://你的用户名.github.io/pgos`

---

## 第 4 步 · 手机设置（30 秒）

1. 手机 Chrome 打开 `https://你的用户名.github.io/pgos`
2. 菜单 **⋮** → **添加到主屏幕**
3. 以后 ntfy 推送点击直接进这个网址

---

## 更新代码（以后改功能时）

1. 在 GitHub 仓库里找到要改的文件（如 `index.html`）
2. 点文件 → 右上角铅笔图标 **✏️ Edit**
3. 全选粘贴新内容 → 页面底部 **Commit changes**
4. 等 30 秒，刷新手机网页即可看到更新

---

## 常见问题

| 问题 | 解决 |
|---|---|
| 打开是 404 | 等 2 分钟再刷新；检查仓库名是否小写 `pgos` |
| 页面样式不对 | 确保 4 个 HTML 都在根目录，不是在文件夹里 |
| 想改成私有仓库 | 不行，GitHub Pages 免费版必须是 Public |
| 数据会丢吗 | 数据存在浏览器 localStorage，换手机/清缓存会丢。长期建议导出备份（Tasks 页有数据导出功能，后续加） |
